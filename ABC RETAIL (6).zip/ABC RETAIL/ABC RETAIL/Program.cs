using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Authentication.Cookies;
using ABC_RETAIL.Services;

var builder = WebApplication.CreateBuilder(args);

// Define the Azure Storage connection string and table names
string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=azuretable;AccountKey=c4DhYo2OiWTgjGdr1ZP2rLmjWBl4qgiXpe4z+uWbEBgts6Ryv/MPHSptsGr038XSCTSnlkoxrpOZ+AStRLQTXg==;EndpointSuffix=core.windows.net";
string customerProfileTableName = "CustomerProfiles";
string productTableName = "Products";
string orderTableName = "Orders";
string containerName = "imageblob";
string queueName = "ABCMessages";
string fileShareName = "yourfileshare";

// Register services with the DI container
builder.Services.AddSingleton(new StorageService(storageConnectionString, customerProfileTableName, productTableName, orderTableName));
builder.Services.AddSingleton(new BlobStorageService(storageConnectionString, containerName));
builder.Services.AddSingleton(new QueueStorageService(storageConnectionString, queueName));
builder.Services.AddSingleton(new FileService(storageConnectionString, fileShareName));

// Register OrderService
builder.Services.AddSingleton<OrderService>();

//register email
builder.Services.AddSingleton<EmailService>();


// Register authentication and authorization services
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
    });
builder.Services.AddAuthorization();

builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();  // Ensure to use authentication
app.UseAuthorization();   // Ensure to use authorization

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
