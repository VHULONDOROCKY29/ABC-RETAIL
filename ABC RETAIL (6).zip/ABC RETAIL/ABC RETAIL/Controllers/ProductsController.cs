﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Threading.Tasks;
using ABC_RETAIL.Models;
using ABC_RETAIL.Services;
using Microsoft.AspNetCore.Http;
using Azure;

namespace ABC_RETAIL.Controllers
{
    public class ProductsController : Controller
    {
        private readonly StorageService _storageService;
        private readonly QueueStorageService _queueStorageService;
        private readonly BlobStorageService _blobStorageService;
        private readonly EmailService _emailService;

        public ProductsController(StorageService storageService, QueueStorageService queueStorageService, BlobStorageService blobStorageService, EmailService emailService)
        {
            _storageService = storageService;
            _queueStorageService = queueStorageService;
            _blobStorageService = blobStorageService;
            _emailService = emailService;
        }

        // GET: Products
        public async Task<IActionResult> Index()
        {
            var products = await _storageService.GetAllProductsAsync();
            return View(products);
        }

        // GET: Products/Details/{partitionKey}/{rowKey}
        public async Task<IActionResult> Details(string partitionKey, string rowKey)
        {
            var product = await _storageService.GetProductAsync(partitionKey, rowKey);
            if (product == null)
            {
                return NotFound();
            }

            ViewBag.ImageUrl = product.ImageUrl ?? null;

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductName,Description,Price,StockQuantity,Category,SKU")] Product product, IFormFile imageFile)
        {
            if (!ModelState.IsValid)
            {
                product.PartitionKey = product.Category;
                product.RowKey = product.SKU;

                // Handle image upload
                if (imageFile != null && imageFile.Length > 0)
                {
                    var imageUrl = await _blobStorageService.UploadBlobAsync(product.RowKey + "/" + imageFile.FileName, imageFile.OpenReadStream());
                    product.ImageUrl = imageUrl;

                    var imageUploadMessage = $"ImageUploaded: {imageFile.FileName}";
                    await _queueStorageService.SendMessageAsync(imageUploadMessage);
                }

                await _storageService.AddProductAsync(product);

                var productCreatedMessage = $"ProductCreated: Product added - Name: {product.ProductName}";
                await _queueStorageService.SendMessageAsync(productCreatedMessage);

                // Send email notification
                var emailBody = $"Product Created:<br>Name: {product.ProductName}<br>Description: {product.Description}<br>Price: {product.Price}<br>Stock: {product.StockQuantity}";
                await _emailService.SendEmailAsync("rockyvhulondo@gmail.com", "New Product Created", emailBody); // Change to appropriate email

                return RedirectToAction(nameof(Details), new { partitionKey = product.PartitionKey, rowKey = product.RowKey });
            }
            return View(product);
        }

        // GET: Products/Edit/{partitionKey}/{rowKey}
        public async Task<IActionResult> Edit(string partitionKey, string rowKey)
        {
            var product = await _storageService.GetProductAsync(partitionKey, rowKey);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: Products/Edit/{partitionKey}/{rowKey}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string partitionKey, string rowKey, [Bind("PartitionKey,RowKey,ProductName,Description,Price,StockQuantity,Category,SKU,ImageUrl,ETag")] Product product, IFormFile newImageFile)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    product.PartitionKey = partitionKey;
                    product.RowKey = rowKey;

                    var existingProduct = await _storageService.GetProductAsync(partitionKey, rowKey);
                    if (existingProduct == null)
                    {
                        return NotFound();
                    }

                    product.ETag = existingProduct.ETag;

                    // Handle image update
                    if (newImageFile != null && newImageFile.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(existingProduct.ImageUrl))
                        {
                            await _blobStorageService.DeleteBlobAsync(existingProduct.ImageUrl);
                        }

                        var newImageUrl = await _blobStorageService.UploadBlobAsync(product.RowKey + "/" + newImageFile.FileName, newImageFile.OpenReadStream());
                        product.ImageUrl = newImageUrl;

                        var imageUpdateMessage = $"ImageUpdated: {newImageFile.FileName}";
                        await _queueStorageService.SendMessageAsync(imageUpdateMessage);
                    }

                    await _storageService.UpdateProductAsync(product);

                    var productUpdateMessage = $"ProductUpdated: Product updated - Name: {product.ProductName}";
                    await _queueStorageService.SendMessageAsync(productUpdateMessage);

                    return RedirectToAction(nameof(Details), new { partitionKey = product.PartitionKey, rowKey = product.RowKey });
                }
                catch (RequestFailedException ex)
                {
                    if (!await ProductExists(partitionKey, rowKey))
                    {
                        return NotFound();
                    }
                    else
                    {
                        Console.WriteLine($"Error updating product: {ex.Message}");
                        return StatusCode(500, "Internal server error");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Unexpected error updating product: {ex.Message}");
                    return StatusCode(500, "Internal server error");
                }
            }
            return View(product);
        }

        // GET: Products/Delete/{partitionKey}/{rowKey}
        public async Task<IActionResult> Delete(string partitionKey, string rowKey)
        {
            var product = await _storageService.GetProductAsync(partitionKey, rowKey);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: Products/DeleteConfirmed
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string partitionKey, string rowKey, string ETag)
        {
            try
            {
                var product = await _storageService.GetProductAsync(partitionKey, rowKey);
                if (product == null)
                {
                    return NotFound();
                }

                if (!string.IsNullOrEmpty(product.ImageUrl))
                {
                    await _blobStorageService.DeleteBlobAsync(product.ImageUrl);
                }

                await _storageService.DeleteProductAsync(partitionKey, rowKey, ETag);

                var productDeletedMessage = $"ProductDeleted: Product removed - Name: {product.ProductName}";
                await _queueStorageService.SendMessageAsync(productDeletedMessage);

                return RedirectToAction(nameof(Index));
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine($"Error deleting product: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error deleting product: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        private async Task<bool> ProductExists(string partitionKey, string rowKey)
        {
            var product = await _storageService.GetProductAsync(partitionKey, rowKey);
            return product != null;
        }
    }
}
