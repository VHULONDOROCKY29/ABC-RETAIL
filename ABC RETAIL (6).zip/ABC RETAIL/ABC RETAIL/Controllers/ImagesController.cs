﻿using ABC_RETAIL.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ABC_RETAIL.Controllers
{
    public class ImagesController : Controller
    {
        private readonly BlobStorageService _blobStorageService;

        public ImagesController(BlobStorageService blobStorageService)
        {
            _blobStorageService = blobStorageService;
        }

        public async Task<IActionResult> Index(string searchQuery = "", string sortBy = "name", int page = 1, int pageSize = 10)
        {
            try
            {
                var blobs = await _blobStorageService.ListBlobsAsync();

                if (!string.IsNullOrEmpty(searchQuery))
                {
                    blobs = blobs.Where(b => b.Contains(searchQuery, StringComparison.OrdinalIgnoreCase)).ToList();
                }

                blobs = sortBy switch
                {
                    "name" => blobs.OrderBy(b => b).ToList(),
                    "date" => blobs.OrderByDescending(b => b).ToList(), // Modify if you have date information
                    _ => blobs.OrderBy(b => b).ToList()
                };

                var paginatedBlobs = blobs.Skip((page - 1) * pageSize).Take(pageSize).ToList();
                ViewData["SearchQuery"] = searchQuery;
                ViewData["SortBy"] = sortBy;
                ViewData["Page"] = page;
                ViewData["PageSize"] = pageSize;
                ViewData["TotalItems"] = blobs.Count;

                return View(paginatedBlobs);
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error fetching blob list: {ex.Message}";
                return View(new List<string>());
            }
        }

        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadBlob(IFormFile file, string blobName)
        {
            if (file == null || file.Length == 0 || string.IsNullOrEmpty(blobName))
            {
                ViewData["ErrorMessage"] = "Invalid file or blob name.";
                return View("Upload");
            }

            try
            {
                using (var stream = file.OpenReadStream())
                {
                    await _blobStorageService.UploadBlobAsync(blobName, stream);
                }
                ViewData["SuccessMessage"] = "File uploaded successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error uploading blob: {ex.Message}";
                return View("Upload");
            }
        }

        public async Task<IActionResult> DownloadBlob(string blobName)
        {
            if (string.IsNullOrEmpty(blobName))
            {
                ViewData["ErrorMessage"] = "Invalid blob name.";
                return RedirectToAction("Index");
            }

            try
            {
                var blobStream = await _blobStorageService.DownloadBlobAsync(blobName);
                return File(blobStream, "application/octet-stream", blobName);
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error downloading blob: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        public async Task<IActionResult> DeleteBlob(string blobName)
        {
            if (string.IsNullOrEmpty(blobName))
            {
                ViewData["ErrorMessage"] = "Invalid blob name.";
                return RedirectToAction("Index");
            }

            try
            {
                var blobExists = await _blobStorageService.BlobExistsAsync(blobName);
                if (!blobExists)
                {
                    ViewData["ErrorMessage"] = $"Blob '{blobName}' not found.";
                    return RedirectToAction("Index");
                }

                await _blobStorageService.DeleteBlobAsync(blobName);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error deleting blob: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        public async Task<IActionResult> ViewImage(string blobName)
        {
            if (string.IsNullOrEmpty(blobName))
            {
                return NotFound();
            }

            try
            {
                var blobStream = await _blobStorageService.DownloadBlobAsync(blobName);
                return File(blobStream, "image/jpeg"); // Adjust MIME type as needed
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error viewing blob: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        public async Task<IActionResult> Gallery()
        {
            try
            {
                var blobs = await _blobStorageService.ListBlobsAsync();
                return View(blobs); // Return all blobs for the gallery view
            }
            catch (Exception ex)
            {
                ViewData["ErrorMessage"] = $"Error fetching gallery: {ex.Message}";
                return View(new List<string>());
            }
        }
    }
}
