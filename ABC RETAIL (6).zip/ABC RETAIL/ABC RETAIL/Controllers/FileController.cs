﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ABC_RETAIL.Models;
using ABC_RETAIL.Services;
using System.Text.RegularExpressions;

namespace ABC_RETAIL.Controllers
{
    public class FileController : Controller
    {
        private readonly FileService _fileService;
        private readonly QueueStorageService _queueStorageService;

        public FileController(FileService fileService, QueueStorageService queueStorageService)
        {
            _fileService = fileService;
            _queueStorageService = queueStorageService;
        }

        public async Task<IActionResult> Index()
        {
            var files = await _fileService.ListFilesAsync();
            var model = new FileViewModel
            {
                Files = files
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Upload(FileViewModel model)
        {
            if (model.File == null || model.File.Length == 0)
            {
                ModelState.AddModelError("", "No file selected for upload.");
                return RedirectToAction("Index");
            }

            string remoteFileName = SanitizeFileName(model.File.FileName);

            using (var stream = model.File.OpenReadStream())
            {
                await _fileService.UploadFileAsync(stream, remoteFileName);
            }

            await _queueStorageService.SendMessageAsync($"File uploaded: {remoteFileName}");

            TempData["Message"] = "File uploaded successfully.";
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Download(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name is required.");
            }

            var tempFilePath = Path.GetTempFileName();

            try
            {
                using (var stream = new FileStream(tempFilePath, FileMode.Create, FileAccess.Write))
                {
                    await _fileService.DownloadFileAsync(fileName, stream);
                }

                var fileBytes = await System.IO.File.ReadAllBytesAsync(tempFilePath);
                System.IO.File.Delete(tempFilePath);

                await _queueStorageService.SendMessageAsync($"File downloaded: {fileName}");

                return File(fileBytes, "application/octet-stream", fileName);
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name is required.");
            }

            await _fileService.DeleteFileAsync(fileName);
            await _queueStorageService.SendMessageAsync($"File deleted: {fileName}");

            TempData["Message"] = "File deleted successfully.";
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> RecycleBin()
        {
            var model = new FileViewModel
            {
                Files = await _fileService.ListDeletedFilesAsync()
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Restore(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name is required.");
            }

            await _fileService.RestoreFileAsync(fileName);
            await _queueStorageService.SendMessageAsync($"File restored: {fileName}");

            TempData["Message"] = "File restored successfully.";
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> DeletePermanently(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name is required.");
            }

            await _fileService.DeletePermanentlyAsync(fileName);
            TempData["Message"] = "File deleted permanently.";
            return RedirectToAction("RecycleBin");
        }

        [HttpPost]
        public async Task<IActionResult> Rename(string oldFileName, string newFileName)
        {
            if (string.IsNullOrEmpty(oldFileName) || string.IsNullOrEmpty(newFileName))
            {
                return BadRequest("File names are required.");
            }

            await _fileService.RenameFileAsync(oldFileName, newFileName);
            await _queueStorageService.SendMessageAsync($"File renamed from {oldFileName} to {newFileName}");

            TempData["Message"] = "File renamed successfully.";
            return RedirectToAction("Index");
        }

        private string SanitizeFileName(string fileName)
        {
            return Regex.Replace(fileName, @"[<>:""/\\|?*]", "_");
        }
    }
}
