﻿using ABC_RETAIL.Services;
using Azure.Storage.Queues.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABC_RETAIL.Controllers
{
    public class QueueController : Controller
    {
        private readonly QueueStorageService _queueStorageService;

        public QueueController(QueueStorageService queueStorageService)
        {
            _queueStorageService = queueStorageService;
        }

        // GET: Queue/Index
        public IActionResult Index()
        {
            return View();
        }

        // POST: Queue/SendMessage
        [HttpPost]
        public async Task<IActionResult> SendMessage(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                ModelState.AddModelError("", "Message cannot be empty.");
                return View("Index");
            }

            await _queueStorageService.SendMessageAsync(message);
            ViewBag.Message = "Message sent to the queue successfully.";
            return View("Index");
        }

        // GET: Queue/DisplayMessages
        public async Task<IActionResult> DisplayMessages()
        {
            var messages = await _queueStorageService.PeekMessagesAsync();
            var viewModel = new List<MessageViewModel>();

            foreach (var message in messages)
            {
                viewModel.Add(new MessageViewModel
                {
                    MessageId = message.MessageId,
                    MessageType = ExtractMessageType(message.MessageText),
                    Content = ExtractMessageContent(message.MessageText),
                    Timestamp = message.InsertedOn?.ToString("g"),
                    PopReceipt = null // PopReceipt is not available from peeked messages
                });
            }

            return View(viewModel); // Ensure this is passed as IEnumerable<MessageViewModel>
        }

        // POST: Queue/DequeueMessage
        [HttpPost]
        public async Task<IActionResult> DequeueMessage()
        {
            var dequeuedMessage = await _queueStorageService.RetrieveAndDeleteMessageAsync();
            if (dequeuedMessage != null)
            {
                ViewBag.DequeuedMessage = $"Dequeued message: {System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(dequeuedMessage.MessageText))}";
            }
            else
            {
                ViewBag.DequeuedMessage = "No message found to dequeue.";
            }

            var messages = await _queueStorageService.PeekMessagesAsync();
            var viewModel = new List<MessageViewModel>();

            foreach (var message in messages)
            {
                viewModel.Add(new MessageViewModel
                {
                    MessageId = message.MessageId,
                    MessageType = ExtractMessageType(message.MessageText),
                    Content = ExtractMessageContent(message.MessageText),
                    Timestamp = message.InsertedOn?.ToString("g"),
                    PopReceipt = null // PopReceipt is not available from peeked messages
                });
            }

            return View("DisplayMessages", viewModel); // Ensure this is passed as IEnumerable<MessageViewModel>
        }

        // POST: Queue/DeleteMessage
        [HttpPost]
        public async Task<IActionResult> DeleteMessage(string messageId, string popReceipt)
        {
            if (string.IsNullOrEmpty(messageId) || string.IsNullOrEmpty(popReceipt))
            {
                ViewBag.ErrorMessage = "Message ID and PopReceipt must be provided.";
                return await DisplayMessages(); // Show the error and refresh the message list
            }

            try
            {
                await _queueStorageService.DeleteMessageAsync(messageId, popReceipt);
                ViewBag.Message = "Message deleted successfully.";
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = $"Failed to delete message: {ex.Message}";
            }

            return await DisplayMessages(); // Refresh the message list
        }

        private string ExtractMessageType(string messageText)
        {
            var parts = DecodeMessage(messageText).Split(":", 2);
            return parts.Length > 1 ? parts[0] : "Unknown";
        }

        private string ExtractMessageContent(string messageText)
        {
            var parts = DecodeMessage(messageText).Split(":", 2);
            return parts.Length > 1 ? parts[1] : "No Content";
        }

        private string DecodeMessage(string messageText)
        {
            return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(messageText));
        }
    }

    public class MessageViewModel
    {
        public string MessageId { get; set; }
        public string MessageType { get; set; }
        public string Content { get; set; }
        public string Timestamp { get; set; }
        public string PopReceipt { get; set; } // Required for deletion
    }
}
