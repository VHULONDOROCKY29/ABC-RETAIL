﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using ABC_RETAIL.Models;
using ABC_RETAIL.Services;

namespace ABC_RETAIL.Controllers
{
    public class OrderController : Controller
    {
        private readonly OrderService _orderService;
        private readonly QueueStorageService _queueService;

        public OrderController(OrderService orderService, QueueStorageService queueService)
        {
            _orderService = orderService;
            _queueService = queueService;
        }

        // Display the order management index page
        public IActionResult Index()
        {
            return View();
        }

        // Display the order placement form
        public IActionResult PlaceOrder()
        {
            return View();
        }

        // Handle the order placement
        [HttpPost]
        public async Task<IActionResult> PlaceOrder(Order order)
        {
            if (order == null || string.IsNullOrEmpty(order.CustomerId) || string.IsNullOrEmpty(order.ProductId))
            {
                ModelState.AddModelError("", "Order details are incomplete.");
                return View(order);
            }

            // Set initial status and order date
            order.Status = "Pending";
            order.OrderDate = DateTime.UtcNow;

            // Add the order to the table storage
            await _orderService.CreateOrderAsync(order);

            // Add a message to the queue for processing
            await _queueService.SendMessageAsync($"New order created: {order.RowKey}");

            ViewBag.Message = "Order placed successfully. You can check the status later.";
            return View();
        }

        // Check the status of an order
        [HttpGet]
        public async Task<IActionResult> OrderStatus(string orderId)
        {
            if (string.IsNullOrEmpty(orderId))
            {
                ViewBag.Status = "Order ID cannot be empty.";
                return View();
            }

            var order = await _orderService.GetOrderAsync("Order", orderId);
            if (order == null)
            {
                ViewBag.Status = $"Order with ID {orderId} not found.";
            }
            else
            {
                ViewBag.Status = order.Status;
            }

            return View();
        }
       
    }
}



