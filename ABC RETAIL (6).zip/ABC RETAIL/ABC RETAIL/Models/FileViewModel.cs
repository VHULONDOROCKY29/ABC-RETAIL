﻿namespace ABC_RETAIL.Models
{
    public class FileViewModel
    {
        public IFormFile File { get; set; }
        public string FileType { get; set; }
        public List<string> Files { get; set; }
    }
}
