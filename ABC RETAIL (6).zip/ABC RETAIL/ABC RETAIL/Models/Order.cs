﻿using Azure;
using Azure.Data.Tables;
using System;
using System.ComponentModel.DataAnnotations;
namespace ABC_RETAIL.Models
{
    public class Order : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; } = ETag.All;

        public DateTime OrderDate { get; set; }
        public string CustomerId { get; set; }
        public string ProductId { get; set; }
        public string Status { get; set; }

        // Constructor for initialization
        public Order() { }

        // Additional properties and methods as needed
    }
}

