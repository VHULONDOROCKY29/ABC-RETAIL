﻿using Azure;
using Azure.Data.Tables;
using System;
using System.ComponentModel.DataAnnotations;

namespace ABC_RETAIL.Models
{
    public class Product : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }

        [Required(ErrorMessage = "Product Name is required")]
        [StringLength(100, ErrorMessage = "Product Name cannot be longer than 100 characters")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Price is required")]
        public string Price { get; set; } // Store Price as string

        [Required(ErrorMessage = "Stock Quantity is required")]
        [Range(0, 10000, ErrorMessage = "Stock Quantity must be between 0 and 10,000")]
        public int StockQuantity { get; set; }

        [Required(ErrorMessage = "Category is required")]
        [StringLength(50, ErrorMessage = "Category cannot be longer than 50 characters")]
        public string Category { get; set; }

        [Required(ErrorMessage = "SKU is required")] // Stock Keeping Unit
        [StringLength(50, ErrorMessage = "SKU cannot be longer than 50 characters")]
        public string SKU { get; set; }

        public string ImageUrl { get; set; }



    }
}
