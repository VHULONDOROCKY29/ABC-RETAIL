﻿using Azure.Storage.Blobs;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class BlobStorageService
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName;

        public BlobStorageService(string connectionString, string containerName)
        {
            _blobServiceClient = new BlobServiceClient(connectionString);
            _containerName = containerName.ToLower(); // Ensure the container name is lowercase
        }

        public async Task<string> UploadBlobAsync(string blobName, Stream data)
        {
            try
            {
                blobName = SanitizeBlobName(blobName);

                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                await containerClient.CreateIfNotExistsAsync();
                var blobClient = containerClient.GetBlobClient(blobName);
                await blobClient.UploadAsync(data, overwrite: true);

                return blobClient.Uri.ToString();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to upload blob", ex);
            }
        }

        public async Task<Stream> DownloadBlobAsync(string blobName)
        {
            try
            {
                blobName = SanitizeBlobName(blobName);

                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = containerClient.GetBlobClient(blobName);

                var ms = new MemoryStream();
                await blobClient.DownloadToAsync(ms);
                ms.Position = 0;
                return ms;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to download blob", ex);
            }
        }

        public async Task DeleteBlobAsync(string blobName)
        {
            try
            {
                blobName = SanitizeBlobName(blobName);

                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = containerClient.GetBlobClient(blobName);
                await blobClient.DeleteIfExistsAsync();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to delete blob", ex);
            }
        }

        public async Task<bool> BlobExistsAsync(string blobName)
        {
            try
            {
                blobName = SanitizeBlobName(blobName);

                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = containerClient.GetBlobClient(blobName);
                return await blobClient.ExistsAsync();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to check blob existence", ex);
            }
        }

        public async Task<List<string>> ListBlobsAsync()
        {
            try
            {
                var containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);

                // Fetch blobs asynchronously
                var blobs = containerClient.GetBlobsAsync();
                var blobNames = new List<string>();

                await foreach (var blobItem in blobs)
                {
                    blobNames.Add(blobItem.Name);
                }

                return blobNames;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to list blobs", ex);
            }
        }

        private string SanitizeBlobName(string blobName)
        {
            return Uri.EscapeDataString(blobName);
        }
    }
}
