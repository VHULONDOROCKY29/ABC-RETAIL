﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class EmailService
    {
        private readonly string _smtpServer = "smtp.gmail.com";
        private readonly int _port = 587;
        private readonly string _username = "vhulondo29@gmail.com";
        private readonly string _password = "tqpp awuv hjrn bhno"; // Use an app password

        public async Task SendEmailAsync(string recipientEmail, string subject, string messageBody)
        {
            var mailMessage = new MailMessage
            {
                From = new MailAddress(_username, "ABC Retail"),
                Subject = subject,
                Body = messageBody,
                IsBodyHtml = true,
            };
            mailMessage.To.Add(recipientEmail);

            using (var smtpClient = new SmtpClient(_smtpServer, _port))
            {
                smtpClient.Credentials = new NetworkCredential(_username, _password);
                smtpClient.EnableSsl = true;

                await smtpClient.SendMailAsync(mailMessage);
            }
        }
    }
}
