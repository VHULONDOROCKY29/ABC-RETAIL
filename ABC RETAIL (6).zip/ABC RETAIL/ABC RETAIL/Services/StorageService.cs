﻿using Azure;
using Azure.Data.Tables;
using ABC_RETAIL.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class StorageService
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly string _customerProfileTableName;
        private readonly string _productTableName;
        private readonly string _orderTableName;

        public StorageService(string storageConnectionString, string customerProfileTableName, string productTableName, string orderTableName)
        {
            try
            {
                _tableServiceClient = new TableServiceClient(storageConnectionString);
                _customerProfileTableName = customerProfileTableName;
                _productTableName = productTableName;
                _orderTableName = orderTableName;

                // Initialize tables
                var customerProfileTableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);
                var productTableClient = _tableServiceClient.GetTableClient(_productTableName);
                var orderTableClient = _tableServiceClient.GetTableClient(_orderTableName);

                customerProfileTableClient.CreateIfNotExists();
                productTableClient.CreateIfNotExists();
                orderTableClient.CreateIfNotExists();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error initializing StorageService: {ex.Message}");
                throw;
            }
        }

        // CustomerProfile Methods
        public async Task AddCustomerProfileAsync(CustomerProfile profile)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);
                profile.PartitionKey = "Customer";
                profile.RowKey = Guid.NewGuid().ToString();
                await tableClient.AddEntityAsync(profile);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding customer profile: {ex.Message}");
                throw;
            }
        }

        public async Task<CustomerProfile> GetCustomerProfileAsync(string partitionKey, string rowKey)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);
                return await tableClient.GetEntityAsync<CustomerProfile>(partitionKey, rowKey);
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine($"RequestFailedException: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving customer profile: {ex.Message}");
                throw;
            }
        }

        public async Task UpdateCustomerProfileAsync(CustomerProfile profile)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);

                if (profile.ETag == null || profile.ETag.Equals(ETag.All))
                {
                    throw new ArgumentException("ETag cannot be empty or All for update operations.");
                }

                await tableClient.UpdateEntityAsync(profile, profile.ETag, TableUpdateMode.Replace);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating customer profile: {ex.Message}");
                throw;
            }
        }

        public async Task DeleteCustomerProfileAsync(string partitionKey, string rowKey, string eTag)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);

                if (string.IsNullOrWhiteSpace(eTag))
                {
                    throw new ArgumentException("ETag cannot be null or empty.");
                }

                var etag = new ETag(eTag);
                await tableClient.DeleteEntityAsync(partitionKey, rowKey, etag);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting customer profile: {ex.Message}");
                throw;
            }
        }

        public async Task<IEnumerable<CustomerProfile>> GetAllCustomerProfilesAsync()
        {
            var tableClient = _tableServiceClient.GetTableClient(_customerProfileTableName);
            var profiles = new List<CustomerProfile>();

            try
            {
                await foreach (var profile in tableClient.QueryAsync<CustomerProfile>())
                {
                    profiles.Add(profile);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving all customer profiles: {ex.Message}");
                throw;
            }

            return profiles;
        }

        // Product Methods
        public async Task AddProductAsync(Product product)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_productTableName);
                product.PartitionKey = "DefaultPartition";
                product.RowKey = Guid.NewGuid().ToString();
                await tableClient.AddEntityAsync(product);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding product: {ex.Message}");
                throw;
            }
        }

        public async Task<Product> GetProductAsync(string partitionKey, string rowKey)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_productTableName);
                return await tableClient.GetEntityAsync<Product>(partitionKey, rowKey);
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine($"RequestFailedException: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving product: {ex.Message}");
                throw;
            }
        }

        public async Task UpdateProductAsync(Product product)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_productTableName);

                if (product.ETag == null || product.ETag.Equals(ETag.All))
                {
                    throw new ArgumentException("ETag cannot be empty or All for update operations.");
                }

                await tableClient.UpdateEntityAsync(product, product.ETag, TableUpdateMode.Replace);
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine($"Error updating product: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error updating product: {ex.Message}");
                throw;
            }
        }

        public async Task DeleteProductAsync(string partitionKey, string rowKey, string eTag)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_productTableName);

                if (string.IsNullOrWhiteSpace(eTag))
                {
                    throw new ArgumentException("ETag cannot be null or empty.");
                }

                var etag = new ETag(eTag);
                await tableClient.DeleteEntityAsync(partitionKey, rowKey, etag);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting product: {ex.Message}");
                throw;
            }
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            var tableClient = _tableServiceClient.GetTableClient(_productTableName);
            var products = new List<Product>();

            try
            {
                await foreach (var product in tableClient.QueryAsync<Product>())
                {
                    products.Add(product);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving all products: {ex.Message}");
                throw;
            }

            return products;
        }

        // Order Methods
        public async Task AddOrderAsync(Order order)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_orderTableName);
                order.PartitionKey = "Order";
                order.RowKey = Guid.NewGuid().ToString();
                await tableClient.AddEntityAsync(order);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding order: {ex.Message}");
                throw;
            }
        }

        public async Task<Order> GetOrderAsync(string partitionKey, string rowKey)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_orderTableName);
                return await tableClient.GetEntityAsync<Order>(partitionKey, rowKey);
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine($"RequestFailedException: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving order: {ex.Message}");
                throw;
            }
        }

        public async Task UpdateOrderAsync(Order order)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_orderTableName);

                if (order.ETag == null || order.ETag.Equals(ETag.All))
                {
                    throw new ArgumentException("ETag cannot be empty or All for update operations.");
                }

                await tableClient.UpdateEntityAsync(order, order.ETag, TableUpdateMode.Replace);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating order: {ex.Message}");
                throw;
            }
        }

        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            var tableClient = _tableServiceClient.GetTableClient(_orderTableName);
            var orders = new List<Order>();

            try
            {
                await foreach (var order in tableClient.QueryAsync<Order>())
                {
                    orders.Add(order);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving all orders: {ex.Message}");
                throw;
            }

            return orders;
        }
    }
}


