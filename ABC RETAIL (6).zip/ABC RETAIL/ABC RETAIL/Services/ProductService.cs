﻿using Azure;
using Azure.Data.Tables;
using ABC_RETAIL.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class ProductService
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly string _tableName;

        public ProductService(TableServiceClient tableServiceClient, string tableName)
        {
            _tableServiceClient = tableServiceClient ?? throw new ArgumentNullException(nameof(tableServiceClient));
            _tableName = tableName ?? throw new ArgumentNullException(nameof(tableName));

            var tableClient = _tableServiceClient.GetTableClient(_tableName);
            tableClient.CreateIfNotExists();
        }

        // Add a new product
        public async Task AddProductAsync(Product product)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_tableName);
                product.PartitionKey = "DefaultPartition"; // Default partition key
                product.RowKey = Guid.NewGuid().ToString(); // Generate a new RowKey
                await tableClient.AddEntityAsync(product);
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                Console.WriteLine($"Error adding product: {ex.Message}");
                throw;
            }
        }

        // Retrieve a product by PartitionKey and RowKey
        public async Task<Product> GetProductAsync(string partitionKey, string rowKey)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_tableName);
                return await tableClient.GetEntityAsync<Product>(partitionKey, rowKey);
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                Console.WriteLine($"Error retrieving product: {ex.Message}");
                throw;
            }
        }

        // Update an existing product
        public async Task UpdateProductAsync(Product product)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_tableName);

                // Ensure ETag is valid
                if (product.ETag == null || product.ETag.Equals(ETag.All))
                {
                    throw new ArgumentException("ETag cannot be empty or All for update operations.");
                }

                await tableClient.UpdateEntityAsync(product, product.ETag, TableUpdateMode.Replace);
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                Console.WriteLine($"Error updating product: {ex.Message}");
                throw;
            }
        }

        // Delete a product by PartitionKey and RowKey
        public async Task DeleteProductAsync(string partitionKey, string rowKey, string eTag)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(_tableName);

                // Validate ETag
                if (string.IsNullOrWhiteSpace(eTag))
                {
                    throw new ArgumentException("ETag cannot be null or empty.");
                }

                var etag = new ETag(eTag);
                await tableClient.DeleteEntityAsync(partitionKey, rowKey, etag);
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                Console.WriteLine($"Error deleting product: {ex.Message}");
                throw;
            }
        }

        // Retrieve all products
        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            var tableClient = _tableServiceClient.GetTableClient(_tableName);
            var products = new List<Product>();

            await foreach (var product in tableClient.QueryAsync<Product>())
            {
                products.Add(product);
            }

            return products;
        }
    }
}
