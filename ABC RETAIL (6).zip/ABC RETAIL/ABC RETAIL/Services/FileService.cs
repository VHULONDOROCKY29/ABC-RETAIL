﻿using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class FileService
    {
        private readonly ShareClient _shareClient;

        public FileService(string connectionString, string shareName)
        {
            _shareClient = new ShareClient(connectionString, SanitizeShareName(shareName));
            _shareClient.CreateIfNotExists();
        }

        public async Task UploadFileAsync(Stream fileStream, string remoteFileName)
        {
            var fileClient = _shareClient.GetRootDirectoryClient().GetFileClient(remoteFileName);

            if (await fileClient.ExistsAsync())
            {
                await fileClient.DeleteAsync();
            }

            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadAsync(fileStream);
        }

        public async Task DownloadFileAsync(string remoteFileName, Stream destinationStream)
        {
            var fileClient = _shareClient.GetRootDirectoryClient().GetFileClient(remoteFileName);

            if (await fileClient.ExistsAsync())
            {
                var downloadResponse = await fileClient.DownloadAsync();
                await downloadResponse.Value.Content.CopyToAsync(destinationStream);
            }
            else
            {
                throw new FileNotFoundException($"File '{remoteFileName}' not found.");
            }
        }

        public async Task DeleteFileAsync(string remoteFileName)
        {
            var fileClient = _shareClient.GetRootDirectoryClient().GetFileClient(remoteFileName);

            if (await fileClient.ExistsAsync())
            {
                var deletedDirectoryClient = _shareClient.GetRootDirectoryClient().GetSubdirectoryClient("DeletedFiles");
                await deletedDirectoryClient.CreateIfNotExistsAsync();

                var deletedFileClient = deletedDirectoryClient.GetFileClient(remoteFileName);
                await deletedFileClient.StartCopyAsync(fileClient.Uri);
                await fileClient.DeleteAsync();
            }
        }

        public async Task DeletePermanentlyAsync(string fileName)
        {
            var deletedDirectoryClient = _shareClient.GetRootDirectoryClient().GetSubdirectoryClient("DeletedFiles");
            var deletedFileClient = deletedDirectoryClient.GetFileClient(fileName);

            if (await deletedFileClient.ExistsAsync())
            {
                await deletedFileClient.DeleteAsync();
            }
        }

        public async Task RenameFileAsync(string oldFileName, string newFileName)
        {
            var oldFileClient = _shareClient.GetRootDirectoryClient().GetFileClient(oldFileName);
            var newFileClient = _shareClient.GetRootDirectoryClient().GetFileClient(newFileName);

            if (await oldFileClient.ExistsAsync())
            {
                await newFileClient.StartCopyAsync(oldFileClient.Uri);
                await oldFileClient.DeleteAsync();
            }
        }

        public async Task<List<string>> ListFilesAsync()
        {
            var files = new List<string>();
            var directoryClient = _shareClient.GetRootDirectoryClient();

            await foreach (var item in directoryClient.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory)
                {
                    files.Add(item.Name);
                }
            }

            return files;
        }

        public async Task<List<string>> ListDeletedFilesAsync()
        {
            var files = new List<string>();
            var deletedDirectoryClient = _shareClient.GetRootDirectoryClient().GetSubdirectoryClient("DeletedFiles");

            await deletedDirectoryClient.CreateIfNotExistsAsync();

            await foreach (var item in deletedDirectoryClient.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory)
                {
                    files.Add(item.Name);
                }
            }

            return files;
        }

        public async Task RestoreFileAsync(string fileName)
        {
            var deletedDirectoryClient = _shareClient.GetRootDirectoryClient().GetSubdirectoryClient("DeletedFiles");
            var deletedFileClient = deletedDirectoryClient.GetFileClient(fileName);
            var restoredFileClient = _shareClient.GetRootDirectoryClient().GetFileClient(fileName);

            if (await deletedFileClient.ExistsAsync())
            {
                await restoredFileClient.StartCopyAsync(deletedFileClient.Uri);
                await deletedFileClient.DeleteAsync();
            }
        }

        private string SanitizeShareName(string shareName)
        {
            return Regex.Replace(shareName, @"[^a-z0-9\-]", "").ToLower();
        }
    }
}
