﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class QueueStorageService
    {
        private readonly QueueClient _queueClient;

        public QueueStorageService(string connectionString, string queueName)
        {
            var queueServiceClient = new QueueServiceClient(connectionString);
            _queueClient = queueServiceClient.GetQueueClient(queueName.ToLower());
            _queueClient.CreateIfNotExists(); // Create the queue if it does not exist
        }

        // Send a message to the queue
        public async Task SendMessageAsync(string message)
        {
            try
            {
                await _queueClient.SendMessageAsync(Convert.ToBase64String(Encoding.UTF8.GetBytes(message)));
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to send message to queue", ex);
            }
        }

        // Peek multiple messages from the queue without changing their visibility
        public async Task<List<PeekedMessage>> PeekMessagesAsync(int maxMessages = 10)
        {
            try
            {
                var response = await _queueClient.PeekMessagesAsync(maxMessages);
                return new List<PeekedMessage>(response.Value);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to peek messages from queue", ex);
            }
        }

        // Retrieve and delete a message from the queue
        public async Task<QueueMessage> RetrieveAndDeleteMessageAsync()
        {
            try
            {
                var response = await _queueClient.ReceiveMessagesAsync(maxMessages: 1);
                if (response.Value.Length > 0)
                {
                    var message = response.Value[0];
                    await _queueClient.DeleteMessageAsync(message.MessageId, message.PopReceipt);
                    return message;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to retrieve and delete message from queue", ex);
            }
        }

        // Delete a specific message
        public async Task DeleteMessageAsync(string messageId, string popReceipt)
        {
            try
            {
                await _queueClient.DeleteMessageAsync(messageId, popReceipt);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to delete message from queue", ex);
            }
        }
    }
}
