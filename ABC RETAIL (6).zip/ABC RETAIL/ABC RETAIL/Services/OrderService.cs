﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ABC_RETAIL.Models;
using ABC_RETAIL.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABC_RETAIL.Services
{
    public class OrderService
    {
        private readonly StorageService _storageService;

        public OrderService(StorageService storageService)
        {
            _storageService = storageService;
        }

        public async Task CreateOrderAsync(Order order)
        {
            await _storageService.AddOrderAsync(order);
        }

        public async Task<Order> GetOrderAsync(string partitionKey, string rowKey)
        {
            return await _storageService.GetOrderAsync(partitionKey, rowKey);
        }

        public async Task UpdateOrderAsync(Order order)
        {
            await _storageService.UpdateOrderAsync(order);
        }

        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _storageService.GetAllOrdersAsync();
        }
    }
}

