﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using System;
using System.Threading.Tasks;
using ABC_RETAIL.Services;
using ABC_RETAIL.Models;

namespace ABC_RETAIL.Services
{
    public class OrderQueueProcessor
    {
        private readonly QueueStorageService _queueStorageService;
        private readonly OrderService _orderService;

        public OrderQueueProcessor(QueueStorageService queueStorageService, OrderService orderService)
        {
            _queueStorageService = queueStorageService;
            _orderService = orderService;
        }

        public async Task ProcessQueueAsync()
        {
            while (true)
            {
                var message = await _queueStorageService.RetrieveAndDeleteMessageAsync();
                if (message == null)
                {
                    await Task.Delay(TimeSpan.FromSeconds(10)); // Wait for a while before checking again
                    continue;
                }

                // Process the message (e.g., create order from message)
                Console.WriteLine($"Processing message: {message}");

                // You should parse and process the message here
                // Example: Creating an order based on message
                // var order = ParseOrderFromMessage(message);
                // await _orderService.CreateOrderAsync(order);
            }
        }

        // Example method to parse order from message (to be implemented)
        private Order ParseOrderFromMessage(string message)
        {
            // Implement parsing logic here
            return new Order(); // Placeholder
        }
    }
}
